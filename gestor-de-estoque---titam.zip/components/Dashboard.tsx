
import React, { useMemo } from 'react';
import { StockEntry, StockSummary } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Package, Truck, ArrowUpRight, TrendingUp } from 'lucide-react';

interface DashboardProps {
  entries: StockEntry[];
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

const Dashboard: React.FC<DashboardProps> = ({ entries }) => {
  const stats = useMemo(() => {
    const inStock = entries.filter(e => ['Estoque', 'Rejeitado'].includes(e.status));
    const totalInStock = inStock.length;
    const totalWeight = inStock.reduce((acc, curr) => acc + (curr.tonelada || 0), 0);
    const totalOut = entries.filter(e => ['Embarcado', 'Devolvido'].includes(e.status)).length;
    
    // Group by supplier
    const supplierMap: Record<string, { count: number; weight: number }> = {};
    inStock.forEach(e => {
      if (!supplierMap[e.fornecedor]) supplierMap[e.fornecedor] = { count: 0, weight: 0 };
      supplierMap[e.fornecedor].count += 1;
      supplierMap[e.fornecedor].weight += e.tonelada;
    });

    const supplierData = Object.entries(supplierMap).map(([name, val]) => ({
      name,
      value: val.count,
      weight: val.weight
    })).sort((a, b) => b.value - a.value).slice(0, 5);

    return { totalInStock, totalWeight, totalOut, supplierData };
  }, [entries]);

  return (
    <div className="space-y-8">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-indigo-50 rounded-lg">
              <Package className="w-6 h-6 text-indigo-600" />
            </div>
            <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">+12%</span>
          </div>
          <p className="text-sm text-slate-500 font-medium">Unidades em Estoque</p>
          <h3 className="text-3xl font-bold text-slate-800 mt-1">{stats.totalInStock}</h3>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-amber-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-amber-600" />
            </div>
            <span className="text-xs font-medium text-amber-600 bg-amber-50 px-2 py-1 rounded-full">Tonelagem</span>
          </div>
          <p className="text-sm text-slate-500 font-medium">Peso Total (TON)</p>
          <h3 className="text-3xl font-bold text-slate-800 mt-1">{stats.totalWeight.toFixed(2)}</h3>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <Truck className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">Saídas</span>
          </div>
          <p className="text-sm text-slate-500 font-medium">Total de Despachos</p>
          <h3 className="text-3xl font-bold text-slate-800 mt-1">{stats.totalOut}</h3>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-rose-50 rounded-lg">
              <ArrowUpRight className="w-6 h-6 text-rose-600" />
            </div>
            <span className="text-xs font-medium text-rose-600 bg-rose-50 px-2 py-1 rounded-full">Eficiência</span>
          </div>
          <p className="text-sm text-slate-500 font-medium">Giro de Estoque</p>
          <h3 className="text-3xl font-bold text-slate-800 mt-1">
            {stats.totalInStock > 0 ? ((stats.totalOut / stats.totalInStock) * 100).toFixed(1) : 0}%
          </h3>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="text-lg font-semibold text-slate-800 mb-6">Estoque por Fornecedor (Top 5)</h4>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.supplierData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" fontSize={12} axisLine={false} tickLine={false} />
                <YAxis fontSize={12} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} name="Unidades" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h4 className="text-lg font-semibold text-slate-800 mb-6">Distribuição de Tonelagem</h4>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.supplierData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="weight"
                  nameKey="name"
                >
                  {stats.supplierData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
